package Nimap.Crud_Apis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class CrudApisApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudApisApplication.class, args);
	}

}